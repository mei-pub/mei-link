Meilink frps Server Setup v1.2.0

Run with sudo:
    sudo ./meilink-setup            # interactive menu
    sudo ./meilink-setup setup      # first-time init
    sudo ./meilink-setup add        # add a domain+token profile
    sudo ./meilink-setup list
    sudo ./meilink-setup start|stop|restart|status [name]
    sudo ./meilink-setup upgrade

Each profile = one domain + one token + one isolated frps systemd service
(frps-<name>.service), auto-enabled and auto-restarted on boot.
